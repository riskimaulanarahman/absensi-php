-- 
-- Editor SQL for DB table absensi
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `absensi` (
	`id` int(10) NOT NULL auto_increment,
	`rfid` numeric(9,2),
	`jam_masuk` datetime,
	`jam_istirahat` datetime,
	`jam_kembali` datetime,
	`jam_pulang` datetime,
	`kegiatan` text,
	PRIMARY KEY( `id` )
);